
# Hava Durumu Uygulaması (Python)

Bu basit Python projesi ile bir şehir ismini girerek anlık hava durumu bilgilerini öğrenebilirsiniz. OpenWeatherMap API'si kullanılarak sıcaklık, hava durumu, nem ve rüzgar bilgileri alınır.

## Özellikler
- Şehir ismine göre güncel hava durumu verisi
- Türkçe açıklamalar ve sade kullanım
- Terminal/Komut satırı üzerinden çalışır

## Kullanım
1. [OpenWeatherMap](https://openweathermap.org/api) sitesine girip ücretsiz API anahtarınızı alın.
2. `weather_app.py` dosyasındaki `API_KEY` kısmına anahtarınızı yazın.
3. Terminalde çalıştırın:
```bash
python weather_app.py
```

## Gereksinimler
- Python 3
- `requests` kütüphanesi

Yüklemek için:
```bash
pip install requests
```
