
import requests

API_KEY = "buraya_senin_api_keyini_yaz"
BASE_URL = "https://api.openweathermap.org/data/2.5/weather"

def hava_durumu_getir(sehir):
    try:
        params = {
            "q": sehir,
            "appid": API_KEY,
            "lang": "tr",
            "units": "metric"
        }
        response = requests.get(BASE_URL, params=params)
        data = response.json()

        if response.status_code == 200:
            print(f"🌤️ {sehir.capitalize()} için Hava Durumu:")
            print(f"Sıcaklık: {data['main']['temp']}°C")
            print(f"Hissedilen: {data['main']['feels_like']}°C")
            print(f"Durum: {data['weather'][0]['description']}")
            print(f"Nem: %{data['main']['humidity']}")
            print(f"Rüzgar Hızı: {data['wind']['speed']} m/s")
        else:
            print("❌ Şehir bulunamadı. Lütfen tekrar deneyin.")
    except Exception as e:
        print("Bir hata oluştu:", e)

if __name__ == "__main__":
    while True:
        sehir = input("Hava durumunu öğrenmek istediğiniz şehri yazın (Çıkmak için q): ")
        if sehir.lower() == 'q':
            break
        hava_durumu_getir(sehir)
